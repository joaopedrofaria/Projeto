from django.urls import path
from . import views

urlpatterns = [
    path('validar_cep/', views.validar_cep, name='url_validar_cep'),
]
