from enderecos.models import Endereco
from django.http import JsonResponse
import requests


def validar_cep(request):
    cep = request.GET.get('cep', None)

    obj = Endereco.objects.filter(cep__iexact=cep).exists()

    if obj:
        consulta_banco_de_dados = Endereco.objects.get(cep__iexact=cep)
        consulta = {
            'endereco': consulta_banco_de_dados.endereco,
            'numero': consulta_banco_de_dados.numero,
            'bairro': consulta_banco_de_dados.bairro,
            'cidade': consulta_banco_de_dados.cidade,
            'uf': consulta_banco_de_dados.uf,
            'complemento': consulta_banco_de_dados.complemento,
            'descricao': consulta_banco_de_dados.descricao
        }
        return JsonResponse(consulta)

    else:
        if len(cep) != 8:
            return JsonResponse({})

        request = requests.get('https://viacep.com.br/ws/{}/json/'.format(cep))
        consulta_api = request.json()

        if 'erro' not in consulta_api:
            consulta = {
                'endereco': consulta_api['logradouro'],
                'bairro': consulta_api['bairro'],
                'cidade': consulta_api['localidade'],
                'uf': consulta_api['uf'],
                'complemento': consulta_api['complemento']
            }
            return JsonResponse(consulta)

        else:
            # TODO: implementar retorno caso o CEP seja inválido
            return JsonResponse({})
