from django.apps import AppConfig


class RecursosConfig(AppConfig):
    name = 'recursos'
