from django.urls import path
from . import views

urlpatterns = [
    path('', views.EnderecoListView.as_view(), name='home'),
    path('cadastrar/', views.EnderecoCreateView.as_view(), name='url_cadastro'),
]
