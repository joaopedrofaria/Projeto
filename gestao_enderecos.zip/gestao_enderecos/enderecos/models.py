from django.db import models


class Endereco(models.Model):
    cep = models.CharField(verbose_name="CEP", max_length=8)
    endereco = models.CharField(verbose_name="Endereço", max_length=255)
    numero = models.CharField(verbose_name="Número", max_length=6)
    complemento = models.CharField(verbose_name="Complemento", max_length=255, blank=True, null=True)
    bairro = models.CharField(verbose_name="Bairro", max_length=255)
    cidade = models.CharField(verbose_name="Cidade", max_length=255)
    uf = models.CharField(verbose_name="UF", max_length=2)
    descricao = models.CharField(verbose_name="Descrição", max_length=255, blank=True, null=True)

    def __str__(self):
        return self.endereco + ", " + self.numero + ", " + self.bairro + ", " + self.cidade + "/" + self.uf + " - CEP " + self.cep
