from django.forms import ModelForm, TextInput, Textarea
from .models import Endereco


class EnderecoForm(ModelForm):
    class Meta:
        model = Endereco
        fields = ('cep', 'endereco', 'numero', 'complemento', 'bairro', 'cidade', 'uf', 'descricao')
        widgets = {
            'cep': TextInput(attrs={'type': 'text', 'class': 'form-control', 'placeholder': 'CEP'}),
            'endereco': TextInput(attrs={'type': 'text', 'class': 'form-control', 'placeholder': 'Informe o seu endereço'}),
            'numero': TextInput(attrs={'class': ''}),
            'complemento': TextInput(attrs={'class': ''}),
            'bairro': TextInput(attrs={'class': ''}),
            'cidade': TextInput(attrs={'type': 'text', 'class': 'form-control', 'placeholder': 'Cidade'}),
            'uf': TextInput(attrs={'type': 'text', 'class': 'form-control', 'placeholder': 'UF'}),
            'descricao': Textarea(attrs={'type': 'text', 'class': 'form-control', 'placeholder': 'Descrição'})
        }
