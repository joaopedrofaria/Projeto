from django.urls import reverse
from django.shortcuts import redirect
from django.views.generic import ListView
from django.views.generic.edit import CreateView
from .models import Endereco
from .form import EnderecoForm


class EnderecoListView(ListView):
    model = Endereco
    template_name = 'enderecos/endereco_list.html'


class EnderecoCreateView(CreateView):
    model = Endereco
    form_class = EnderecoForm
    template_name = 'enderecos/endereco_new.html'

    def form_valid(self, form):
        try:
            f = form.save(commit=False)
            e = self.model.objects.get(cep=f.cep)

            # TODO: Quando aprender a desenvolver em Django, altarar essa gambiarra aqui!
            e.endereco = f.endereco
            e.numero = f.numero
            e.bairro = f.bairro
            e.cidade = f.cidade
            e.uf = f.uf
            e.complemento = f.complemento
            e.descricao = f.descricao

            e.save()

            return redirect('home')
        except Endereco.DoesNotExist:
            return super().form_valid(form)

    def get_success_url(self):
        return reverse('home')
